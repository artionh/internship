package main;

import entity.Employee;
import entity.Passport;
import entity.Person;
import repository.PersonRepository;
import service.EmployeeService;
import service.EmployeeServiceImpl;

public class Main {
    public static void main(String[] args) {
        EmployeeService employeeService = new EmployeeServiceImpl();

        Employee employee = employeeService.findById(1);

        System.out.println(employee);

        System.out.println("Deleting employee with id 2");
        employeeService.deleteEmployee(2);

        PersonRepository pr = new PersonRepository();

        Person find = pr.getPersonById(1);
        System.out.println("find");
        System.out.println(find);

    }
}
