package service;

import entity.Employee;

import java.util.List;

public interface EmployeeService {

    Employee addEmployee(Employee employee);

    void deleteEmployee(Integer id);

    Employee findById(Integer id);

    List<Employee> findAll();
}
