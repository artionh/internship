package service;

import entity.Employee;
import repository.Emp2RepositoryImpl;
import repository.EmployeeRepository;
import repository.EmployeeRepositoryImpl;

import java.util.List;

public class EmployeeServiceImpl implements EmployeeService {

    EmployeeRepository employeeRepository = new EmployeeRepositoryImpl();
    EmployeeRepository emp2 = new Emp2RepositoryImpl();

    @Override
    public Employee addEmployee(Employee employee) {
        return null;
    }

    @Override
    public void deleteEmployee(Integer id) {
        employeeRepository.deleteEmployee(id);
    }

    @Override
    public Employee findById(Integer id) {
        return employeeRepository.findById(id);
    }

    @Override
    public List<Employee> findAll() {
        return null;
    }
}
