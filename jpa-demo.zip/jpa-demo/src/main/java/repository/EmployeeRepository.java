package repository;

import entity.Employee;

import java.util.List;

public interface EmployeeRepository {

    Employee addEmployee(Employee employee);

    void deleteEmployee(Integer id);

    Employee findById(Integer id);

    List<Employee> findAll();
}
