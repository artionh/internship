package repository;

import entity.Employee;
import model.EmployeeFilter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.Collections;
import java.util.List;

public class EmployeeRepositoryImpl implements EmployeeRepository {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("employeesDB");
    EntityManager em = emf.createEntityManager();

    @Override
    public Employee addEmployee(Employee employee) {
        return null;
    }

    @Override
    public void deleteEmployee(Integer id) {
        Employee employee = findById(id);
        if (employee != null) {
            em.getTransaction().begin();
            em.remove(employee);
            em.getTransaction().commit();
        }
    }

    @Override
    public Employee findById(Integer id) {
        return em.find(Employee.class, id);
    }

    @Override
    public List<Employee> findAll() {
        TypedQuery<Employee> query = em.createNamedQuery("Employee.findAll", Employee.class);
        if (query.getResultList().isEmpty()) {
            return Collections.emptyList();
        }
        return query.getResultList();
    }

    public Employee findByEmail(String email) {
        TypedQuery<Employee> query = em.createNamedQuery("Employee.findByEmail", Employee.class);
        query.setParameter("email", email);
        return query.getSingleResult();
    }

    public List<Employee> findByCustomParameters(EmployeeFilter filter) {
        StringBuilder sb = new StringBuilder("SELECT e from Employee  e WHERE e.firstName = :firstName");

        if (filter.getLastName() != null) {
            sb.append(" OR e.lastName = :lastName");
        }
        if (filter.getEmail() != null) {
            sb.append(" OR e.email = :email");
        }

        TypedQuery<Employee> query = em.createQuery(sb.toString(), Employee.class);

        query.setParameter("firstName", filter.getFirstName());
        if (filter.getLastName() != null) {
            query.setParameter("lastName", filter.getLastName());
        }
        if (filter.getEmail() != null) {
            query.setParameter("email", filter.getEmail());
        }

        return query.getResultList();
    }
}
