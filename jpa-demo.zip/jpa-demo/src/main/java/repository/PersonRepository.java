package repository;

import entity.Person;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersonRepository {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("employeesDB");
    EntityManager em = emf.createEntityManager();

    public Person addPerson(Person person) {
        System.out.println("--------PERSON ID--------");
        System.out.println(person.getId());
        em.getTransaction().begin();
        em.persist(person);
        System.out.println(person.getId());
        em.getTransaction().commit();
        return person;
    }

    public Person updatePerson(Person person) {
        em.getTransaction().begin();

        em.persist(person.getPassport());
        em.flush();
        em.merge(person);
        em.getTransaction().commit();
        return person;
    }

    public Person getPersonById(Integer id) {
        return em.find(Person.class, id);
    }
}
