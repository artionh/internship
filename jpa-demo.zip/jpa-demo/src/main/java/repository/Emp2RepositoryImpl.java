package repository;

import entity.Employee;

import java.util.List;

public class Emp2RepositoryImpl implements EmployeeRepository {
    @Override
    public Employee addEmployee(Employee employee) {
        return null;
    }

    @Override
    public void deleteEmployee(Integer id) {

    }

    @Override
    public Employee findById(Integer id) {
        return null;
    }

    @Override
    public List<Employee> findAll() {
        return null;
    }
}
