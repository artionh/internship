package service;

import dto.DetailedOrder;
import dto.ShoppingCart;

import java.util.List;

public interface OrderService {

    boolean save(Integer numberOfProducts, Double price);

    Integer findLatestOrderIdForUser();

    void addNewOrder(ShoppingCart shoppingCart, Integer numberOfProducts, Double price);

    List<DetailedOrder> findAllOrdersByUserId();

    DetailedOrder findOrderDetailsByUserIdForRestaurant(Integer orderId);
}
