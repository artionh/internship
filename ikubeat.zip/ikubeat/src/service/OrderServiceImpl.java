package service;

import dto.CartItem;
import dto.DetailedOrder;
import dto.ShoppingCart;
import repository.OrderProductsRepository;
import repository.OrderRepository;

import java.util.List;

public class OrderServiceImpl implements OrderService {

    public final OrderRepository orderRepository = new OrderRepository();
    public final OrderProductsRepository orderProductsRepository = new OrderProductsRepository();

    @Override
    public void addNewOrder(ShoppingCart shoppingCart, Integer numberOfProducts, Double totalPrice) {
        boolean isInserted = save(numberOfProducts, totalPrice);
        if (isInserted) {
            Integer orderId = findLatestOrderIdForUser();
            List<CartItem> items = shoppingCart.getCartItems();
            for (CartItem item : items) {
                orderProductsRepository.save(item, orderId);
            }
        }
    }

    @Override
    public List<DetailedOrder> findAllOrdersByUserId() {
        return orderRepository.findAllOrdersByUserId();
    }

    @Override
    public DetailedOrder findOrderDetailsByUserIdForRestaurant(Integer orderId) {
        return orderRepository.findOrderDetailsByUserIdForRestaurant(orderId);
    }

    @Override
    public boolean save(Integer numberOfProducts, Double price) {
        return orderRepository.save(numberOfProducts, price);
    }

    @Override
    public Integer findLatestOrderIdForUser() {
        return orderRepository.findLatestOrderIdForUser();
    }
}
