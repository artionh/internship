package exception;

public class ValueExistsException extends RuntimeException {

    public ValueExistsException(String message) {
        super(message);
    }
}
