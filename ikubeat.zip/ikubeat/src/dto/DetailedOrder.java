package dto;

import enums.OrderStatus;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class DetailedOrder {
    private Integer orderId;
    private String client;
    private OrderStatus status;
    private String restaurantName;
    private Double totalPrice;
    private Date orderDate;
    private List<ProductDto> products = new ArrayList<>();

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public List<ProductDto> getProducts() {
        return products;
    }

    public void setProducts(List<ProductDto> products) {
        this.products = products;
    }

    @Override
    public String toString() {
        return "DetailedOrder{" +
                "orderId=" + orderId +
                ", client='" + client + '\'' +
                ", status=" + status +
                ", restaurantName='" + restaurantName + '\'' +
                ", totalPrice=" + totalPrice +
                ", orderDate=" + orderDate +
                ", products=" + products +
                '}';
    }
}
