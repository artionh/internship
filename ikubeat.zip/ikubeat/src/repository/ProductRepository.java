package repository;

import model.Product;
import util.JdbcConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static util.Queries.FIND_ALL_PRODUCTS_FROM_ACTIVE_MENU_BY_RESTAURANT_NAME;

public class ProductRepository {

    public List<Product> findAllProductsOfActiveMenuByRestaurantName(String restaurantName) {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(FIND_ALL_PRODUCTS_FROM_ACTIVE_MENU_BY_RESTAURANT_NAME)) {
            ps.setString(1, restaurantName);
            ResultSet rs = ps.executeQuery();
            List<Product> products = new ArrayList<>();
            while (rs.next()) {
                Product p = new Product();
                p.setId(rs.getInt("id"));
                p.setMenuId(rs.getInt("menu_id"));
                p.setName(rs.getString("name"));
                p.setDescription(rs.getString("description"));
                p.setPrice(rs.getDouble("price"));
                p.setIngredients(rs.getString("ingredients"));
                p.setCategoryId(rs.getInt("category_id"));
                products.add(p);
            }
            return products;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return Collections.emptyList();
    }
}
