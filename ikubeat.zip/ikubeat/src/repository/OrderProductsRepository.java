package repository;

import dto.CartItem;
import util.JdbcConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import static util.Queries.INSERT_ORDER_PRODUCTS;

public class OrderProductsRepository {

    public void save(CartItem item, Integer orderId) {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(INSERT_ORDER_PRODUCTS)) {
            ps.setInt(1, orderId);
            ps.setInt(2, item.getProductId());
            ps.setInt(3, item.getQuantity());
            ps.execute();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
