package repository;

import dto.DetailedOrder;
import dto.ProductDto;
import enums.OrderStatus;
import model.Order;
import util.JdbcConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static main.Main.auth;
import static util.Queries.*;

public class OrderRepository {

    public boolean save(Integer numberOfProducts, Double price) {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(INSERT_ORDER)) {
            ps.setInt(1, auth.getId());
            ps.setInt(2, numberOfProducts);
            ps.setDouble(3, price);
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    public Integer findLatestOrderIdForUser() {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(FIND_LATEST_ORDER_ID_FOR_USER)) {
            ps.setInt(1, auth.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return 0;
    }

    public List<Order> findAllAndSortByDateDESC() {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(GET_ALL_ORDERS_SORTED_BY_DATE_DESC)) {
            ResultSet rs = ps.executeQuery();
            return fromResultSetToOrdersList(rs);
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return Collections.emptyList();
    }

    public void changeOrderStatus(Integer orderId, OrderStatus status) {
        Order order = findOrderById(orderId);
        if (order != null) {
            if ((order.getStatus().equals(OrderStatus.CREATED) && status.equals(OrderStatus.APPROVED) ||
                    (order.getStatus().equals(OrderStatus.CREATED) && status.equals(OrderStatus.REJECTED))) ||
                    (order.getStatus().equals(OrderStatus.APPROVED) && status.equals(OrderStatus.PREPARED)) ||
                    (order.getStatus().equals(OrderStatus.PREPARED) && status.equals(OrderStatus.DELIVERED))
            ) {
                try (Connection connection = JdbcConnection.connect();
                     PreparedStatement ps = connection.prepareStatement(UPDATE_ORDER_STATUS)) {
                    ps.setString(1, status.getValue());
                    ps.setInt(2, orderId);
                    ps.executeUpdate();
                } catch (SQLException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }

    public Order findOrderById(Integer id) {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(FIND_ORDER_BY_ID)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Order order = new Order();
                order.setId(rs.getInt("id"));
                order.setUserId(rs.getInt("user_id"));
                String orderStatus = rs.getString("status");
                order.setStatus(OrderStatus.findStatus(orderStatus));
                order.setOrderDate(rs.getDate("order_date"));
                order.setTotalPrice(rs.getDouble("total_price"));
                order.setNumberOfProducts(rs.getInt("number_of_products"));
                return order;
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return null;
    }

    public List<Order> findAllByRestaurantId() {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(FIND_ALL_ORDERS_BY_RESTAURANT_ID)) {
            ps.setInt(1, auth.getRestaurantId());
            ResultSet rs = ps.executeQuery();
            return fromResultSetToOrdersList(rs);
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return Collections.emptyList();
    }

    public String checkOrderStatus(Integer orderId) {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(CHECK_ORDER_STATUS)) {
            ps.setInt(1, orderId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString(1);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return "";
    }

    public List<DetailedOrder> findAllOrdersByUserId() {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(FIND_ALL_ORDERS_BY_USER_ID)) {
            ps.setInt(1, auth.getId());
            ResultSet rs = ps.executeQuery();
            List<DetailedOrder> list = new ArrayList<>();
            Integer lastOrderId = null;
            while (rs.next()) {
                Integer orderId = rs.getInt("order_id");
                if (lastOrderId != orderId) {
                    DetailedOrder detailedOrder = new DetailedOrder();
                    detailedOrder.setOrderId(rs.getInt("order_id"));
                    detailedOrder.setClient(rs.getString("client"));
                    String status = rs.getString("order_status");
                    detailedOrder.setStatus(OrderStatus.findStatus(status));
                    detailedOrder.setRestaurantName(rs.getString("restaurant_name"));
                    detailedOrder.setTotalPrice(rs.getDouble("total_price"));
                    detailedOrder.setOrderDate(rs.getDate("order_date"));
                    ProductDto p = new ProductDto();
                    p.setName(rs.getString("product_name"));
                    p.setIngredients(rs.getString("ingredients"));
                    p.setPrice(rs.getDouble("price"));
                    detailedOrder.setProducts(new ArrayList<>(Arrays.asList(p)));
                    list.add(detailedOrder);
                } else {
                    DetailedOrder detailedOrder = new DetailedOrder();
                    Integer index = null;
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).getOrderId().equals(lastOrderId)) {
                            detailedOrder = list.get(i);
                            index = i;
                            break;
                        }
                    }

                    if (index != null) {
                        list.remove(index.intValue());
                        ProductDto p = new ProductDto();
                        p.setName(rs.getString("product_name"));
                        p.setIngredients(rs.getString("ingredients"));
                        p.setPrice(rs.getDouble("price"));
                        detailedOrder.getProducts().add(p);
                        list.add(detailedOrder);
                    }
                }
                lastOrderId = orderId;
            }
            return list;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return Collections.emptyList();
    }

    public DetailedOrder findOrderDetailsByUserIdForRestaurant(Integer orderId) {
        try (Connection connection = JdbcConnection.connect();
             PreparedStatement ps = connection.prepareStatement(FIND_ORDER_DETAILS_BY_ORDER_ID)) {
            ps.setInt(1, orderId);
            ps.setInt(2, auth.getRestaurantId());
            ResultSet rs = ps.executeQuery();
            DetailedOrder detailedOrder = new DetailedOrder();
            while (rs.next()) {
                if (detailedOrder.getProducts().isEmpty()) {
                    detailedOrder.setOrderId(rs.getInt("order_id"));
                    detailedOrder.setClient(rs.getString("client"));
                    String status = rs.getString("order_status");
                    detailedOrder.setStatus(OrderStatus.findStatus(status));
                    detailedOrder.setRestaurantName(rs.getString("restaurant_name"));
                    detailedOrder.setTotalPrice(rs.getDouble("total_price"));
                    detailedOrder.setOrderDate(rs.getDate("order_date"));
                    ProductDto p = new ProductDto();
                    p.setName(rs.getString("product_name"));
                    p.setIngredients(rs.getString("ingredients"));
                    p.setPrice(rs.getDouble("price"));
                    detailedOrder.setProducts(new ArrayList<>(Arrays.asList(p)));
                } else {
                    ProductDto p = new ProductDto();
                    p.setName(rs.getString("product_name"));
                    p.setIngredients(rs.getString("ingredients"));
                    p.setPrice(rs.getDouble("price"));
                    detailedOrder.getProducts().add(p);
                }
            }
            return detailedOrder;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return null;
    }

    private List<Order> fromResultSetToOrdersList(ResultSet rs) throws SQLException {
        List<Order> orders = new ArrayList<>();
        while (rs.next()) {
            Order o = new Order();
            o.setId(rs.getInt("id"));
            o.setUserId(rs.getInt("user_id"));
            o.setNumberOfProducts(rs.getInt("number_of_products"));
            o.setTotalPrice(rs.getDouble("total_price"));
            o.setOrderDate(rs.getDate("order_date"));
            String status = rs.getString("status");
            o.setStatus(OrderStatus.findStatus(status));
            orders.add(o);
        }
        return orders;
    }
}
